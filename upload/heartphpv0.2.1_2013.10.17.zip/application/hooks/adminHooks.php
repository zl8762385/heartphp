<?php

class adminHooks {
	public function ad1($data) {
		echo '<br/> ad11';
	}

	public function ad2($data) {
		echo '<br/> ad22';
	}

}