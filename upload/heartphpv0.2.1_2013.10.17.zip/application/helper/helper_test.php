<?php
if(!defined('IS_HEARTPHP')) exit('Access Denied');
/**
 *  助手工具包 form转换 input html
 *
 * @copyright			(C) 20013-2015 HeartPHP
 * @author              zhangxiaoliang  <zl8762385@163.com> <qq:979314>  
 * @lastmodify			2013.05.28
 *
 * 您可以自由使用该源码，但是在使用过程中，请保留作者信息。尊重他人劳动成果就是尊重自己
 */
class helper_test extends base_Controller {
	
	public function test() {
		echo 'helper_test  tttt';
	}
}
