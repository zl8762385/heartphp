<?php
			$rt_data["life"] = 0;
			$rt_data["data"] = '123123';
		?>