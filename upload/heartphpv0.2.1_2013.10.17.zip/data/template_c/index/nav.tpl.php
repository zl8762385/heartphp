<? if(!defined('IS_HEARTPHP')) exit('Access Denied');/*Create On##1372321081|Compiled from##/workspace/webapps/heartphp.com/tpl/index/news.html*/?>
    <div class="box">
        <div class="logo"></div>
        <ul>
            <li class="help current"><a href="#" onclick="javascript:alert('开发中...')">新闻</a></li>
           
            <li class="jailbreak "><a href="<?php echo $config['domain'] ?>manuals/index.html" target="_blank">在线手册</a></li>
            <li class="pc "><a target="_blank" href="<?php echo $config['domain'] ?>admin/index/login">在线演示</a></li>
            <li class="ios "><a href="#" onclick="javascript:alert('开发中...')">关于HeartPHP</a></li>
            <li class="home "><a href="<?php echo $config['domain'] ?>" onclick="_hmt.push([&#39;_trackEvent&#39;, &#39;index&#39;, &#39;click&#39;]);">首页</a></li>
        </ul>
        <div class="clearfix"></div>
    </div>