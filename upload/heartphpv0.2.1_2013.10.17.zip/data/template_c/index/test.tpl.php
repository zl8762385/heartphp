<? if(!defined('IS_HEARTPHP')) exit('Access Denied');/*Create On##1373543425|Compiled from##D:/PHPnow/htdocs/heartphp/tpl/index/test.html*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>HeartPHP - 用心做PHP、简单、高效、上手快</title>
<meta name="description" content="HeartPHP <?php echo $infos['title'] ?>">
<meta name="keywords" content="PHP <?php echo $infos['title'] ?>">
<link rel="stylesheet" href="<?php echo $config['static_path_css'] ?>default.css" charset="utf-8">
<script type="text/javascript" src="<?php echo $config['static_path_js'] ?>jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="<?php echo $config['static_path_js'] ?>ad.util.js"></script>
</head>

<body>
<?php $s = '123aaaaa'; ?>
<?php echo $s;; ?>
</body>
</html>