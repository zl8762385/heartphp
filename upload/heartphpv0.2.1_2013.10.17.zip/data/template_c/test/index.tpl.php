<? if(!defined('IS_HEARTPHP')) exit('Access Denied');/*Create On##1372303265|Compiled from##/workspace/webapps/heartphp.com/tpl/test/index.html*/?>
indexxxx